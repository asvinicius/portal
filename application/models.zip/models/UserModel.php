<?php
class UserModel extends CI_Model{
    
    public function listing(){
        $this->db->select('*');
        return $this->db->get("user")->result();
    }
    
    public function getuser($userid){
        $this->db->where("userid", $userid);
        
        return $this->db->get("user")->row_array();
    }
}